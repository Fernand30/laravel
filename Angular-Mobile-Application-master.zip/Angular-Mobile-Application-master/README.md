# Angular-Mobile-Application
Digital Prescriptions for medical analyses
